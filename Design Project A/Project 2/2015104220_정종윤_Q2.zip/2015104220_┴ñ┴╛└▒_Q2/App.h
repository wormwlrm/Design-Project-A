#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include "Message.h"
#include "User.h"
using namespace std;

class App
{
private:
	int** Router;
	vector<User*> Users;
	User* loginedUser;
public:
	App(void);
	~App(void);
	void run();
	int loadRouter();
	int loadUser();
	User* login(int _ID, string _PW);
	void logout();
	void printMenu();

	int sendText();
};

