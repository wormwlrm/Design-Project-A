#include "Message.h"


Message::	Message(void)
{
}

Message::~Message(void)
{
}

Text::Text()
{
}

Text::~Text()
{
}
	
void Text::printInfo()
{
	cout << content << endl;
}


Image::	Image()
{
}

Image::~Image()
{
}

void Image::printInfo()
{
	cout << name << "." << hwakjang << endl;
}