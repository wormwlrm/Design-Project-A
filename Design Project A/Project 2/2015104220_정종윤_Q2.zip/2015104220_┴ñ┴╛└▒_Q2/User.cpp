#include "User.h"


User::User(void)
{
}


User::~User(void)
{
}

User::User(int _ID, string _PW, string _Name)
{
	ID = _ID;
	PW = _PW;
	Name = _Name;
}

void User:: printUserInfo()
{
	cout << "���̵� : "  << ID  << endl;
	cout << "�̸� :" << Name << endl << endl;
	cout << "������� ģ�� ��� : " << endl;
	for(int i = 0 ; i < FriendList.size(); i++)
	{
		cout << i+1 << ". " << FriendList.at(i)->getID() << " " << getUserNameByID(FriendList.at(i)->getID()) << endl;
	}
}

int User:: getID()
{
	return ID;
}

string  User::getPW()
{
	return PW;
}

string User::getName()
{
	return Name;
}

vector<User*> User:: getFriendList()
{
	return FriendList;
}

string User::getUserNameByID(int ID)
{
	if (ID == 0)
		return "ȫ�浿";
	else if( ID == 1)
		return "�̼���";
	else if(ID == 2)
		return "������";
	else if((ID == 3))
		return "������";
	else if(ID == 4)
		return "������";
	else if(ID == 5)
		return "���缮";

	return NULL;
}

void User::printReceivedMessage()
{
	for(int i = 0 ; i < ReceivedMessage.size() ; i++)
	{
		ReceivedMessage.at(i)->printInfo();
	}
}