#pragma once
#include <string>
#include <iostream>
using namespace std;

class Message
{
protected:
	
public:
	Message(void);
	~Message(void);
	virtual void printInfo() = 0;
};

class Text : public Message
{
private:
	string* content;
public:
	Text();
	~Text();
	void printInfo();
};

class Image : public Message
{
private:
	string* name;
	string* hwakjang;
public:
	Image();
	~Image();
	void printInfo();
};