#pragma once
#include <string>
#include <vector>
#include <iostream>
#include "Message.h"

using namespace std;

class User
{
private:
	int ID;
	string PW;
	string Name;
	vector<User*> FriendList;
	vector<Message*>ReceivedMessage;
	vector<Message*>SendMessage;
	Message* Classify;

public:
	User(void);
	User(int ID, string PW, string Name);
	~User(void);
	void printUserInfo();

	int getID();
	string getPW();
	string getName();
	vector<User*> getFriendList();

	void printReceivedMessage();

	string getUserNameByID(int ID);
};

