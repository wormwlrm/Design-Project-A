#include "App.h"
#include <iostream>
using namespace std;

int main()
{
	App Application;
	Application.run();

	return 0;
}