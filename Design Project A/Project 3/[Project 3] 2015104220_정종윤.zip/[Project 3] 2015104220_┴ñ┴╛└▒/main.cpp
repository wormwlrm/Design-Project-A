#include "App.h"
using namespace std;

int main()
{
	App Application;
	Application.run();

	return 0;
}