#include "Application.h"
using namespace std;

int main()
{
	Application App;
	App.run();

	return 0;
}